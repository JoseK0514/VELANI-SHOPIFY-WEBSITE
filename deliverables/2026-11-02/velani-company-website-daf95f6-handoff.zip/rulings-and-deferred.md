# Decisions and pending scope

Ruling: use a new isolated local repository on codex/velani-company-site-20261102 — no Velani repo exists in the connected installation; mixing source into NEVORA would be wrong. Cost if wrong: GitHub destination still needs selection later.

Ruling: preserve this ledger and original evidence — the user's preservation requirement overrides automatic scratch cleanup. Cost: small retained storage.

Ruling: local browser verification will use the installed Chromium/Playwright because sites-preview is absent; real Shopify acceptance will be reported separately. Cost: local rendering cannot certify Shopify platform behavior.

Ruling: native draft navigation uses supported alternate index templates and the exact preview theme ID instead of publishing global Page resources — preserves store scope — cost: hosted routing remains unaccepted until authenticated Shopify review.

Ruling: execute real WebKit using existing user-space dependencies linked only in this checkout's ignored browser cache; skip only the host ldconfig preflight that cannot see them — browser actually launches and executes checks — cost: another environment needs standard Playwright host dependencies.

Ruling: retain exact WebKit screenshot-driver CSP messages as capture diagnostics, and keep all other console/page errors as failures — source and controlled screenshot reproduction show the SDK injects body {} to sync animations — cost: classification is tied to this SDK and exact capture-time message.

Final: Ruling: treat consent loading overwrite and failed keyboard-withdrawal focus loss (M1/M2) as Important interaction-integrity gaps — visitors should not lose their selected state or land on the opposite action after failure — cost: a small additional correction/verification pass in the draft.

Final: Ruling: treat no-JavaScript enabled-but-dead privacy buttons (M4) as Important availability misrepresentation — enable only after wiring and explain fallback — cost: no-JS visitors see a disabled control and explanation.

Final: Ruling: correct the Minor inventory label (M3) as part of the user's explicit request for exact environment state, an exception to the skill's default minor-deferral rule — old summary confused 70 verified package files with 96 total remote files — cost: consumers of this new report need the clarified field names. Original summaries remain unchanged.

Final: Ruling: hosted acceptance, real delivery and global store cutover remain pending, as do legal finality, full assistive-technology/toolbar-zoom and field performance — these were explicitly set aside by the reviewer and exceed this protected draft's proved/authorized scope — cost: owner review cannot be treated as publication or product-launch acceptance. NEVORA remains In development and untouched.

Deferred review findings: none. The original reviewer’s four minor findings and the parent’s pending-save reproduction were addressed and verified. Pending hosted/publication/legal/platform/full-conformance/field-performance scope is documented in review-response.md and HANDOFF.md.
