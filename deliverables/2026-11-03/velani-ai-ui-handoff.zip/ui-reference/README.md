# Existing Shopify assistant reference

Pinned UI commit: f7304188b44050a699887b7f6e6749848a86beea on branch claude/velani-night-nevora-setup-k9sbcy.

These selected files are reference extracts, NOT a standalone build. Continue in the full UI checkout. Current deployment truth is in ../services/velani-ai/docs/CLAUDE-UI-START-HERE.md; the older UI handoff is a historical snapshot.

Keep the generated assist.js and velani-assistant.js modules adjacent. assist.css depends on base.css tokens and shared styles. assist.html needs Phosphor icon expansion and data-api injection performed by src/night.mjs. src/render.mjs conditionally emits the assistant from settings.assistant_api_url. scripts/build.mjs generates the settings schema; there is no committed standalone schema file.

The full build reads additional templates, content modules, SVGs and assets not duplicated here. Use Node 24 and the complete UI checkout's locked dependencies. Local tests use Playwright/Axe, the UI server and a mock backend/challenge; they do not establish production Cloudflare or AI readiness.

The compatible assistant is already installed on UNPUBLISHED theme 192990773562. Re-read its role/settings immediately before changes. Once the real API is healthy, setting assistant_api_url may be the only activation change needed. Former preview 192986808634 is now MAIN.
